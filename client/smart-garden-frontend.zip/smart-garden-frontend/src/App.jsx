import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import PremiumDashboard from './pages/PremiumDashboard.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';

const getUser = () => {
  const raw = localStorage.getItem('sg_user');
  return raw ? JSON.parse(raw) : null;
};

function RoleRouter() {
  const user = getUser();
  if (!user) return <Navigate to="/login" />;
  if (user.role === 'admin') return <AdminDashboard />;
  if (user.role === 'premium') return <PremiumDashboard />;
  return <Dashboard />; // regular
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/dashboard" />} />
      <Route path="/login" element={<Login />} />
      <Route path="/dashboard" element={<RoleRouter />} />
      <Route path="*" element={<Navigate to="/dashboard" />} />
    </Routes>
  );
}

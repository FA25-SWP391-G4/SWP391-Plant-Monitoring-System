import React from 'react';

export function StatCard({ title, value, unit, icon, variant = 'success' }) {
  const colors = {
    success: 'text-bg-success',
    warning: 'text-bg-warning',
    info: 'text-bg-info',
    secondary: 'text-bg-secondary',
  };
  return (
    <div className={`card shadow-sm border-0 ${colors[variant]} bg-opacity-10`}>
      <div className="card-body d-flex align-items-center justify-content-between">
        <div>
          <div className="small text-muted">{title}</div>
          <div className="fs-4 fw-semibold">{value}{unit}</div>
        </div>
        <div className="fs-3">{icon}</div>
      </div>
    </div>
  );
}

export function PumpControl({ isOn, onToggle }) {
  return (
    <div className="card shadow-sm border-0">
      <div className="card-body">
        <div className="d-flex align-items-center justify-content-between">
          <div>
            <div className="fw-semibold">Pump Control</div>
            <div className="text-muted small">Manual override</div>
          </div>
          <div className="form-check form-switch fs-4">
            <input className="form-check-input" type="checkbox" role="switch" checked={isOn} onChange={onToggle} />
          </div>
        </div>
      </div>
    </div>
  );
}

export function AlertsPanel({ items }) {
  return (
    <div className="card shadow-sm border-0">
      <div className="card-body">
        <div className="fw-semibold mb-2">Alerts</div>
        {items.length === 0 && <div className="text-muted">All good — no alerts.</div>}
        <ul className="list-group list-group-flush">
          {items.map((a, i) => (
            <li key={i} className={`list-group-item d-flex align-items-start gap-2 border-0 ${a.type === 'danger' ? 'text-danger' : 'text-warning'}`}>
              <span>{a.type === 'danger' ? '⛔' : '⚠️'}</span>
              <div>
                <div className="fw-medium">{a.title}</div>
                <div className="small text-muted">{a.detail}</div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export function Toasts({ toasts, onClose }) {
  return (
    <div className="position-fixed top-0 end-0 p-3" style={{ zIndex: 1080 }}>
      {toasts.map((t) => (
        <div key={t.id} className={`toast show align-items-center mb-2 text-white ${t.variant || 'bg-success'}`} role="alert">
          <div className="d-flex">
            <div className="toast-body">{t.msg}</div>
            <button type="button" className="btn-close btn-close-white me-2 m-auto" onClick={() => onClose(t.id)}></button>
          </div>
        </div>
      ))}
    </div>
  );
}

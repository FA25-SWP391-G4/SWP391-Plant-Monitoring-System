import React from 'react';
import { Line, Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale, LinearScale, PointElement, LineElement, BarElement, Tooltip, Legend,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Tooltip, Legend);

export function HistoryLine({ labels, series }) {
  const data = {
    labels,
    datasets: [
      { label: 'Soil Moisture (%)', data: series.soil, borderWidth: 2, tension: 0.35 },
      { label: 'Light (%)', data: series.light, borderWidth: 2, tension: 0.35 },
      { label: 'Humidity (%)', data: series.humidity, borderWidth: 2, tension: 0.35 },
      { label: 'Temperature (°C)', data: series.temp, borderWidth: 2, tension: 0.35 },
    ],
  };
  const options = { responsive: true, plugins: { legend: { position: 'bottom' } } };
  return <Line data={data} options={options} />;
}

export function WaterBar({ labels, values }) {
  const data = { labels, datasets: [{ label: 'Water Level (%)', data: values, borderWidth: 1 }] };
  const options = { responsive: true, plugins: { legend: { position: 'bottom' } } };
  return <Bar data={data} options={options} />;
}

import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ChatBox from '../components/ChatBox.jsx';
import { ParamRadar, exportCsv } from '../components/PremiumCharts.jsx';
import { clamp } from '../utils/store.js'; // clamp not here; provide quick local:
const clampLocal = (v, min, max) => Math.max(min, Math.min(max, v));

export default function PremiumDashboard() {
  const nav = useNavigate();
  const [user] = useState(()=> JSON.parse(localStorage.getItem('sg_user')||'{}'));
  useEffect(()=>{ if(!user?.role) nav('/login'); }, []);

  const [dark, setDark] = useState(() => localStorage.getItem('sg_theme') === 'dark');
  useEffect(() => { document.body.setAttribute('data-bs-theme', dark ? 'dark' : 'light'); localStorage.setItem('sg_theme', dark?'dark':'light'); }, [dark]);

  const [plants, setPlants] = useState([
    { id:'1', title:'Monstera', moisture:64, light:58, temp:22.5, humidity:57 },
    { id:'2', title:'Fiddle Leaf Fig', moisture:28, light:63, temp:23.3, humidity:42 },
  ]);
  const [selected, setSelected] = useState('1');

  const plant = plants.find(p => p.id === selected) || plants[0];
  const [history, setHistory] = useState(() =>
    Array.from({length:20}).map((_,i)=>({ t:i, soil: 55+i%5, light: 60 - (i%7), temp: 22 + (i%3), humid: 50+(i%4) }))
  );

  const onWater = () => {
    setPlants(prev => prev.map(p => p.id===plant.id ? { ...p, moisture: clampLocal(p.moisture+10,0,100) } : p));
    setHistory(h => [...h, { t:h.length, soil: plant.moisture+10, light: plant.light, temp: plant.temp, humid: plant.humidity }].slice(-100));
  };
  const onDimLight = () => {
    setPlants(prev => prev.map(p => p.id===plant.id ? { ...p, light: clampLocal(p.light-10,0,100) } : p));
  };

  const csvRows = history.map(r => ({ time:r.t, soil:r.soil, light:r.light, temp:r.temp, humidity:r.humid }));

  const onLogout = () => { localStorage.removeItem('sg_user'); nav('/login'); };

  return (
    <>
      <nav className="navbar navbar-expand bg-white border-bottom sticky-top">
        <div className="container-fluid">
          <span className="navbar-brand fw-semibold text-success"><i className="bi bi-flower1 me-2"></i>Smart Garden — Premium</span>
          <div className="ms-auto d-flex align-items-center gap-2">
            <button className="btn btn-sm btn-outline-dark" onClick={()=>setDark(d=>!d)}>{dark?'Light':'Night'} Mode</button>
            <button className="btn btn-sm btn-outline-secondary" onClick={onLogout}>Sign out</button>
          </div>
        </div>
      </nav>

      <div className="container my-3">
        <div className="row g-3">
          <div className="col-lg-8">
            <div className="card sg p-3">
              <div className="d-flex justify-content-between align-items-center">
                <div className="fw-semibold">Plant Parameters (Radar)</div>
                <div className="d-flex gap-2">
                  <select className="form-select form-select-sm" value={selected} onChange={e=>setSelected(e.target.value)}>
                    {plants.map(p => <option key={p.id} value={p.id}>{p.title}</option>)}
                  </select>
                  <button className="btn btn-success btn-sm" onClick={onWater}><i className="bi bi-droplet me-1"></i>Water</button>
                  <button className="btn btn-outline-secondary btn-sm" onClick={onDimLight}><i className="bi bi-brightness-low me-1"></i>Dim Light</button>
                  <button className="btn btn-outline-success btn-sm" onClick={()=>exportCsv(csvRows)}><i className="bi bi-file-earmark-arrow-down me-1"></i>Export CSV</button>
                </div>
              </div>
              <div className="mt-2">
                <ParamRadar plant={plant} dark={dark} />
              </div>
            </div>
          </div>

          <div className="col-lg-4">
            <div className="card sg p-3">
              <div className="fw-semibold mb-2"><i className="bi bi-robot me-2"></i>AI Chat</div>
              <ChatBox />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

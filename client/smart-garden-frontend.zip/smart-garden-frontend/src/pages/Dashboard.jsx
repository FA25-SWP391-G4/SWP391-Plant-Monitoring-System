import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { computeAlerts, clamp } from "../utils/mock.js";

const fmtPct = (n) => `${n.toFixed(1)}%`;
const fmtTemp = (n) => `${n.toFixed(1)}°C`;

function Navbar({ user, dark, toggleTheme, alertCount, onLogout }) {
  return (
    <nav className="navbar navbar-expand bg-white border-bottom sticky-top">
      <div className="container-fluid">
        <span className="navbar-brand fw-semibold text-success">
          <i className="bi bi-flower1 me-2"></i>Smart Garden
        </span>
        <div className="ms-auto d-flex align-items-center gap-3">
          <button className="btn btn-sm btn-outline-secondary" onClick={toggleTheme}>
            {dark ? "Light" : "Dark"}
          </button>
          <button className="btn btn-sm btn-outline-secondary position-relative">
            <i className="bi bi-bell"></i>
            <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-success">
              {alertCount}
            </span>
          </button>
          <span className="text-muted small">Hello, {user?.name || "Alex"}</span>
          <button className="btn btn-sm btn-outline-secondary" onClick={onLogout}>
            Sign out
          </button>
        </div>
      </div>
    </nav>
  );
}

/* --------- Plant Card --------- */
function PlantCard({ plant, onWater, onAdjustLight }) {
  const statusChip =
    plant.status === "Good" ? (
      <span className="chip chip-soft">Good</span>
    ) : (
      <span className="chip chip-gray"><i className="bi bi-exclamation-triangle-fill me-1 text-warning"></i>Needs attention</span>
    );

  return (
    <div className="card sg p-3">
      <div className="d-flex justify-content-between align-items-start">
        <div>
          <div className="d-flex align-items-center gap-2">
            <div className="icon-circle">{plant.icon}</div>
            <div>
              <div className="fw-semibold">{plant.title}</div>
              <div className="text-muted small">{plant.sub}</div>
            </div>
          </div>
        </div>
        {statusChip}
      </div>

      <div className="mt-3">
        {/* Moisture */}
        <div className="d-flex justify-content-between small">
          <span className="text-muted">Moisture</span>
          <span className="text-success fw-semibold">{fmtPct(plant.moisture)}</span>
        </div>
        <div className="metric metric-moisture mt-1"><span style={{ width: `${plant.moisture}%` }} /></div>

        {/* Light */}
        <div className="d-flex justify-content-between small mt-2">
          <span className="text-muted">Light</span>
          <span className="fw-semibold">{fmtPct(plant.light)}</span>
        </div>
        <div className="metric metric-light mt-1"><span style={{ width: `${plant.light}%` }} /></div>

        {/* Temp / Humidity inline chips */}
        <div className="d-flex gap-2 flex-wrap mt-2">
          <span className="chip chip-gray">
            <i className="bi bi-thermometer-sun me-1"></i>{fmtTemp(plant.temp)}
          </span>
          <span className="chip chip-gray">
            <i className="bi bi-droplet me-1"></i>{fmtPct(plant.humidity)}
          </span>
        </div>

        <div className="row mt-2 g-2 small text-muted">
          <div className="col">
            <div>Last watered</div>
            <div className="fw-medium">{plant.lastWatered}</div>
          </div>
          <div className="col">
            <div>Next action</div>
            <div className="fw-medium">{plant.nextAction}</div>
          </div>
        </div>

        <div className="d-flex gap-2 mt-3">
          <button className="btn btn-success btn-pill" onClick={() => onWater(plant.id)}>Water</button>
          <button className="btn btn-outline-secondary btn-pill" onClick={() => onAdjustLight(plant.id)}>Adjust Light</button>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const nav = useNavigate();
  const [user] = useState(() => {
    const raw = localStorage.getItem("sg_user");
    return raw ? JSON.parse(raw) : { name: "Alex" };
  });
  useEffect(() => { if (!user) nav("/login"); }, [user]);

  /* Theme */
  const [dark, setDark] = useState(() => localStorage.getItem("sg_theme") === "dark");
  useEffect(() => {
    document.body.setAttribute("data-bs-theme", dark ? "dark" : "light");
    localStorage.setItem("sg_theme", dark ? "dark" : "light");
  }, [dark]);

  /* Plants */
  const [plants, setPlants] = useState([
    { id:"1", title:"Monstera", sub:"Monstera deliciosa", icon:"🌿", status:"Good", moisture:50.9, light:89.9, temp:22.1, humidity:45, lastWatered:"9/14/2025, 4:15 PM", nextAction:"Water in 2 days" },
    { id:"2", title:"Fiddle Leaf Fig", sub:"Ficus lyrata", icon:"🪴", status:"Needs", moisture:29.8, light:64.7, temp:26.1, humidity:42, lastWatered:"9/17/2025, 1:30 AM", nextAction:"Water today" },
    { id:"3", title:"Rosemary", sub:"Salvia rosmarinus", icon:"🌿", status:"Needs", moisture:45.5, light:89.6, temp:26, humidity:39, lastWatered:"9/17/2025, 2:05 PM", nextAction:"Reduce light" },
    { id:"4", title:"Snake Plant", sub:"Sansevieria", icon:"🌵", status:"Good", moisture:58, light:48.7, temp:13.2, humidity:47, lastWatered:"9/10/2025, 6:45 PM", nextAction:"No action needed" },
  ]);

  const [activity, setActivity] = useState([
    "09:02  Moisture reading updated for Monstera",
    "08:41  Light spike detected on Rosemary",
    "Yesterday  Auto-watering completed for Fiddle Leaf Fig"
  ]);

  /* Quick numbers (top right chips) */
  const healthyCount = plants.filter(p => p.status === "Good").length;
  const sensorsCount = 7;

  /* Alerts panel (right side box) */
  const healthAlerts = useMemo(() => {
    const alerts = [];
    plants.forEach(p => {
      const a = computeAlerts({ soil: p.moisture, water: 100 }); // water tank not per-plant here
      a.forEach(_ => {
        if (p.moisture < 30) alerts.push(`Fiddle Leaf Fig soil is dry. Consider watering today.`);
      });
      if (p.light > 85 && p.title === "Rosemary") {
        alerts.push("Rosemary receiving intense light. Move to partial shade.");
      }
    });
    return [...new Set(alerts)];
  }, [plants]);

  /* Actions */
  const addActivity = (msg) => setActivity(a => [msg, ...a].slice(0, 15));

  const waterPlant = (id) => {
    setPlants(prev => prev.map(p => p.id === id ? ({
      ...p,
      moisture: clamp(p.moisture + 20, 0, 100),
      lastWatered: new Date().toLocaleString(),
      status: "Good",
      nextAction: "Water in 2 days"
    }) : p));
    const name = plants.find(p => p.id === id)?.title || "Plant";
    addActivity(`Watered ${name}`);
  };

  const adjustLight = (id) => {
    setPlants(prev => prev.map(p => p.id === id ? ({
      ...p,
      light: clamp(p.light - 12, 0, 100),
      nextAction: p.light > 70 ? "Reduce light" : "Maintain light"
    }) : p));
    const name = plants.find(p => p.id === id)?.title || "Plant";
    addActivity(`Adjusted light for ${name}`);
  };

  const waterNowGlobal = () => {
    // pick driest plant
    const driest = [...plants].sort((a,b)=>a.moisture-b.moisture)[0];
    if (driest) waterPlant(driest.id);
  };

  const adjustLightingGlobal = () => {
    // pick brightest plant
    const brightest = [...plants].sort((a,b)=>b.light-a.light)[0];
    if (brightest) adjustLight(brightest.id);
  };

  const addPlant = () => {
    const name = prompt("Common name:");
    if (!name) return;
    const species = prompt("Species (optional):") || "Unknown";
    const p = {
      id: crypto.randomUUID(), title: name, sub: species, icon: "🪴", status: "Good",
      moisture: 60, light: 55, temp: 22, humidity: 50,
      lastWatered: new Date().toLocaleString(), nextAction: "Water in 2 days"
    };
    setPlants(prev => [p, ...prev]);
    addActivity(`Added plant: ${name}`);
  };

  const onLogout = () => { localStorage.removeItem("sg_user"); nav("/login"); };

  const alertCount = healthAlerts.length;

  return (
    <>
      <Navbar
        user={user}
        dark={dark}
        toggleTheme={() => setDark(d => !d)}
        alertCount={alertCount}
        onLogout={onLogout}
      />

      {/* Hero */}
      <div className="container mt-3">
        <div className="hero p-4 p-md-5">
          <div className="d-flex align-items-start justify-content-between flex-wrap gap-3">
            <div>
              <h3 className="fw-bold mb-1">Welcome back, {user?.name || "Alex"}</h3>
              <div className="text-muted">Your plants are thriving. Here’s a quick overview.</div>
            </div>
            <div className="d-flex flex-wrap gap-2">
              <button className="btn btn-success btn-pill" onClick={waterNowGlobal}>
                <i className="bi bi-droplet me-2"></i>Water Now
              </button>
              <button className="btn btn-outline-success btn-pill" onClick={adjustLightingGlobal}>
                <i className="bi bi-brightness-high me-2"></i>Adjust Lighting
              </button>
              <button className="btn btn-outline-secondary btn-pill" onClick={addPlant}>
                <i className="bi bi-plus-circle me-2"></i>Add Plant
              </button>
              <button className="btn btn-outline-dark btn-pill" onClick={() => setDark(d=>!d)}>
                <i className="bi bi-moon-stars me-2"></i>Night Mode
              </button>
            </div>
          </div>

          {/* Chips on the right */}
          <div className="mt-3 d-flex flex-wrap gap-2">
            <span className="chip chip-soft">Healthy {healthyCount}</span>
            <span className="chip chip-gray">Sensors {sensorsCount}</span>
            <span className="chip chip-soft">Alerts {alertCount}</span>
          </div>
        </div>
      </div>

      <div className="container my-3">
        <div className="row g-3">
          {/* Plant cards (3 across + 1 below, like screenshot) */}
          <div className="col-lg-4 col-md-6"><PlantCard plant={plants[0]} onWater={waterPlant} onAdjustLight={adjustLight} /></div>
          <div className="col-lg-4 col-md-6"><PlantCard plant={plants[1]} onWater={waterPlant} onAdjustLight={adjustLight} /></div>
          <div className="col-lg-4 col-md-6"><PlantCard plant={plants[2]} onWater={waterPlant} onAdjustLight={adjustLight} /></div>

          {/* Right side widgets */}
          <div className="col-lg-4 order-lg-4 order-5">
            <div className="card sg p-3 mb-3">
              <div className="d-flex align-items-center justify-content-between">
                <div className="fw-semibold"><i className="bi bi-heart-pulse me-2 text-warning"></i>Health Alerts</div>
                <span className="chip chip-gray">{alertCount}</span>
              </div>
              <ul className="list-unstyled mt-2 mb-0 small">
                {healthAlerts.length === 0 && <li className="text-muted">All good — no alerts.</li>}
                {healthAlerts.map((a, idx) => (
                  <li key={idx} className="mb-2 p-2 rounded" style={{background:"#fff7e6"}}>
                    {a}
                  </li>
                ))}
              </ul>
            </div>

            <div className="card sg p-3">
              <div className="fw-semibold mb-2"><i className="bi bi-geo-alt me-2"></i>Local Weather <span className="text-muted small ms-1">San Luis Obispo</span></div>
              <div className="d-flex gap-2">
                <div className="card sg flex-fill text-center p-3">
                  <div className="text-muted small">Temp</div><div className="fw-bold">21°C</div>
                </div>
                <div className="card sg flex-fill text-center p-3">
                  <div className="text-muted small">Humidity</div><div className="fw-bold">63%</div>
                </div>
                <div className="card sg flex-fill text-center p-3">
                  <div className="text-muted small">Wind</div><div className="fw-bold">8 km/h</div>
                </div>
              </div>
            </div>
          </div>

          {/* Second row left-most plant card (Snake Plant) */}
          <div className="col-lg-4 col-md-6 order-4">
            <PlantCard plant={plants[3]} onWater={waterPlant} onAdjustLight={adjustLight} />
          </div>

          {/* Care schedule */}
          <div className="col-lg-4 order-6">
            <div className="card sg p-3">
              <div className="fw-semibold mb-2"><i className="bi bi-calendar2-check me-2"></i>Care Schedule</div>
              <ul className="list-unstyled small mb-0">
                <li className="d-flex align-items-center gap-2 mb-2">
                  <i className="bi bi-check-circle text-success"></i>
                  <div>Today — Water Fiddle Leaf Fig</div>
                </li>
                <li className="d-flex align-items-center gap-2 mb-2">
                  <i className="bi bi-check-circle text-success"></i>
                  <div>Tomorrow — Rotate Monstera for even light</div>
                </li>
                <li className="d-flex align-items-center gap-2 mb-2">
                  <i className="bi bi-check-circle text-success"></i>
                  <div>Thu — Fertilize Rosemary</div>
                </li>
                <li className="d-flex align-items-center gap-2">
                  <i className="bi bi-check-circle text-success"></i>
                  <div>Sat — Prune Snake Plant pups</div>
                </li>
              </ul>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="col-lg-4 order-7">
            <div className="card sg p-3">
              <div className="fw-semibold mb-2"><i className="bi bi-clock-history me-2"></i>Recent Activity</div>
              <ul className="small mb-0">
                {activity.map((a, i) => <li key={i} className="mb-1">{a}</li>)}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
